function [EMI,yhat]=EMI_minmax(Samp,YS,x,m,F1)



for i=1:m
    k = oodacefit( Samp, YS(:,i) );
     [yhat(:,i) predvar(:,i)] = k.predict(x);
end

yBest=[F1.Cost]';
nx=size(x,1);
for i=1:nx
    IM=EMI_Matrix(yBest,yhat(i,:),predvar(i,:));
    EMI(i)=min(max(IM,[],2));
end



