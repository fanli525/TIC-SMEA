 function [PS,t1,Samp,YS]=TIC_SMEA(CostFunction,nVar, nObj,VarMin,VarMax,maxNFE)
%clc;clear;CostFunction=@(x)zdt1(x);PF_CostFunction=@PF_zdt1;nVar=8;nObj=2;VarMin=0*ones(1,nVar);,VarMax=1*ones(1,nVar);maxNFE=200;

% -----------------------------------------------------------------------------
% -----------------------------------------------------------------------------
% Input:
%CostFunction       - Name of the problem
% nVar                  - Dimension of the problem
% nObj                 - number of the objective functions
% VarMin             - Lower Boundary of Decision Variables
% VarMax            - Upper Boundary of Decision Variables
%maxNFE            - number of  maximum function evaluations
% Output:
% PS                    - the obtained best fitness value
% t1                     -  the obtained best fitness value in each iteration
% Samp               - all the evaluted samples
%YS                     - fitness vaules of all the evaluted samples
%--------------------------------------------------------------------------------------
% -------------------------------------------------------------------------------------
% Authors:      Li, Fan; Gao, Liang; Garg, Akhil; Shen, Weiming; Huang, Shifeng
% Address       Huazhong University of Science & Technology, Wuhan, PR China;
% DATE:         July 2021
%This code is part of the program that produces the results in the following paper:
% Two infill criteria driven surrogate-assisted multi-objective evolutionary algorithms for computationally expensive problems with medium dimensions[J]. Swarm and Evolutionary Computation, 2021, 60: 100774.
%You are free to use it for non-commercial purposes. However, we do not offer any forms of guanrantee or warranty associated with the code. We would appreciate your acknowledgement.
%% *********************************************************************************************************************************************************************************************************



t0=cputime;
%% Problem Definition
VarSize = [1 nVar]; % Size of Decision Variables Matrix
%% NSGA-II Parameters
if nObj==2;nZr=30;N_PF=500; elseif nObj==3;nZr=105; N_PF=950; else;nZr=256; end
[W,nZr] = UniformPoint(nZr,nObj);
Zr =W';
nZr=size(Zr,2);
nPop =max(80,nZr);  % Population Size
if nObj==3
    nPop=106;
end

pCrossover = 0.5;       % Crossover Percentage
nCrossover = 2*round(pCrossover*nPop/2); % Number of Parnets (Offsprings)
pMutation = 0.5;       % Mutation Percentage
nMutation = round(pMutation*nPop);  % Number of Mutants
mu = 0.02;     % Mutation Rate
sigma = 0.1*(VarMax-VarMin); % Mutation Step Size


%% Colect Parameters

params.nPop = nPop;
params.Zr = Zr;
params.nZr = size(Zr,2);
params.zmin = [];
params.zmax = [];
params.smin = [];

%% Initialization

empty_individual.Position = [];
empty_individual.Cost = [];
empty_individual.Rank = [];
empty_individual.DominationSet = [];
empty_individual.DominatedCount = [];
empty_individual.NormalizedCost = [];
empty_individual.AssociatedRef = [];
empty_individual.DistanceToAssociatedRef = [];
empty_individual.Isreal= 0;

pop = repmat(empty_individual, nPop, 1);
npoints=nPop;
 
LHS =DOELHS(npoints, nVar,5);
LHS = ScaleVariable(LHS , [0 1]'*ones(1,nVar), [VarMin;VarMax]);
Xtrain=LHS;
for i = 1:nPop
    pop(i).Position = Xtrain(i,:);
    pop(i).Cost = CostFunction(pop(i).Position);
    pop(i).Isreal=1;
    Samp(i,:)=pop(i).Position;
end
YS=[    pop.Cost ]';NFE=nPop;
% Sort Population and Perform Selection
[pop, F, params] = SortAndSelectPopulation(pop, params);
[pop, d, rho] = AssociateToReferencePoint(pop, params);
dalt=min(1.0e-3,5*(1.0e-4)*sqrt(nVar)*min(VarMax-VarMin));

%% NSGA-II Main Loop
it=1;
nfk=2; Fcost1=[];

F1 = pop(F{1});wmax=3;%3

ys2=[F1.Cost];

Run_pop7=1;
while NFE<maxNFE
    
    w=0;
    while w<wmax
        %% ***************************************************************************
        % Crossover
        Offspring=pro_off(pop,VarMin,VarMax);
        popc = repmat(empty_individual, nPop/2, 1);
        
        for i = 1:nPop/2
            popc(i).Position = Offspring(i,:);
            popc(i).Position = min(   popc(i).Position, VarMax);
            popc(i).Position = max(   popc(i).Position, VarMin);
        end
        % Mutation
        popm = repmat(empty_individual, nMutation, 1);
        for k = 1:nMutation
            popm(k).Position = Offspring(k+nPop/2,:);
            popm(k).Position = max(popm(k).Position , VarMin);
            popm(k).Position = min(popm(k).Position , VarMax);
        end
        %}
        
        % ProOffsp;
        %% ************************************************************************************************
        % Ԥ���������Ŀ��ֵ
        s0=size(popc,1);
        for i=1:s0
            popcm(i,:)=popc(i).Position;
        end
        for i=s0+1:s0+size(popm,1)
            popcm(i,:)=popm(i-s0).Position;
        end
        fpopcm=preObj1(Samp,YS,popcm,nObj);
        for i=1:size(popc,1)
            popc(i).Cost=fpopcm(i,:)';
        end
        for i=s0+1:s0+size(popm,1)
            popm(i-s0).Cost=fpopcm(i,:)';
        end
        popc=popObj(popc,params); popm=popObj(popm,params);
        [popc, d, rho] = AssociateToReferencePoint(popc, params);
        [popm, d, rho] = AssociateToReferencePoint(popm, params);
        if w==wmax-1
            W=[0.0,1];%������ ������   a1Ϊ�������������
            if size(F1,1)>0
                a=[F1.AssociatedRef ];
                a=unique(a);
                a1=setdiff([1:nZr], a);
            else
                a1=[1:nZr];
            end
            a2=a1;nfk=3;
        end
        pop=[pop;popc;popm];
        [pop, params] = NormalizePopulation(pop, params);
        [pop, d, rho] = AssociateToReferencePoint(pop, params);
        [popq1,popq2]=selectPar(Zr', pop);
        params.nPop=nPop-size(popq1,1);
        [popq2, F, params1] = SortAndSelectPopulation(popq2, params);
        pop=[popq1;popq2];params.nPop=nPop;
        w=w+1;
    end
    
    %% ����pop��ǰ�ķ�֧������Ŀ���������ѡ���Ӵ�
    %% �ҳ��ǿղο�����
    if size(F1,1)>0
        a=[F1.AssociatedRef ];
        a=unique(a);
        a1=setdiff([1:nZr], a);
    else
        a1=[1:nZr];
    end
    
    pop5=pop;
    pop6=[];
    if  NFE<maxNFE
        [pop6,NFE,Samp,YS]=minObj(Samp,YS,NFE,nObj,CostFunction,maxNFE,dalt);
    end
    if size(pop6,1)>0
        pop6=pop6';
        pop5=[pop5;pop6];
    end
    
    %% ***********************************************************************************************
    %%��ȷ��������
    pop7=[];
    NMI=3;
    if  NFE<maxNFE & Run_pop7==1
        [EMI,yhat]=EMI_minmax(Samp,YS,popcm,nObj,F1);
        popcm7=[popc;popm];
        [val,ind]=sort(-EMI);
        pop7=popcm7(ind(1:NMI));
    end
    pop71=[];
    for i=1:size(pop7,1)
        dx=min(sqrt(sum((repmat(pop7(i).Position,size(Samp,1),1)-Samp).^2,2)));
        if dx>dalt
            pop7(i).Cost=CostFunction( pop7(i).Position);
            pop7(i).Isreal=1;
            NFE=NFE+1;    Samp=[Samp;pop7(i).Position];
            YS=[ YS;   pop7(i).Cost' ];
            pop71=[ pop71;pop7(i)];
        end
    end
    pop7=pop71;
    pop5=[pop5;pop7];


    
    %% ���²���

    F1=select_ALLNO(Samp,YS);
    params.zmin = [];
    params.zmax = [];
    params.smin = [];
    [F1, params] = NormalizePopulation(F1, params);
    %%
    s0=size(popc,1);
    for i=1:s0
        popcm(i,:)=popc(i).Position;
    end
    for i=s0+1:s0+size(popm,1)
        popcm(i,:)=popm(i-s0).Position;
    end
    fpopcm=preObj1(Samp,YS,popcm,nObj);
    for i=1:size(popc,1)
        popc(i).Cost=fpopcm(i,:)';
    end
    for i=s0+1:s0+size(popm,1)
        popm(i-s0).Cost=fpopcm(i,:)';
    end
    popc=popObj(popc,params); popm=popObj(popm,params);
    [popc, d, rho] = AssociateToReferencePoint(popc, params);
    [popm, d, rho] = AssociateToReferencePoint(popm, params);
    pop5=[pop5;popc;popm];
    
    F1=select_ALLNO(Samp,YS);
    params.zmin = [];
    params.zmax = [];
    params.smin = [];
    [F1, params] = NormalizePopulation(F1, params);
    [F1, d, rho] = AssociateToReferencePoint(F1, params);
    [pop, F2, params1] = SortAndSelectPopulation(pop5, params);
    [ pop5, TF]=NonDominatedSorting(pop5);
    TF1 = pop5(TF{1});
    F12=[];
    for i=1:size(TF1 ,1)
        if   TF1 (i).Isreal==0
            F12=[F12;TF1(i)];
        end
    end
    nadd=3;        pop21=[];predy=[];pop2=[];pop_test=[];
    if size(F12,1)>0
        pop2=RV_solu2(F12,F1,Zr,nadd);
        
        for i=1:size(pop2,1)
            dx=min(sqrt(sum((repmat(pop2(i).Position,size(Samp,1),1)-Samp).^2,2)));
            if dx>dalt & NFE<maxNFE
                predy=[predy;pop2(i).Cost'];
                pop2(i).Cost=CostFunction( pop2(i).Position);
                pop2(i).Isreal=1;
                NFE=NFE+1;    Samp=[Samp;pop2(i).Position];pop_test=[pop_test;pop2(i)];
                YS=[ YS;   pop2(i).Cost' ];
                pop21=[ pop21;pop2(i)];
            end
        end
        pop2=pop21;
     
    end
    
    
    F1=select_ALLNO(Samp,YS);
    params.zmin = [];
    params.zmax = [];
    params.smin = [];
    [F1, params] = NormalizePopulation(F1, params);
    [F1, d, rho] = AssociateToReferencePoint(F1, params);
    % ����pop�������Ӧֵ
    for i=1:size(pop,1)
        pop_posi(i,:)=pop(i).Position;
    end
    fpopcm=preObj1(Samp,YS,pop_posi,nObj);
    
    for i=1:size(pop,1)
        pop(i).Cost=fpopcm(i,:)';
    end
    %% ����pop popc popm ��Ԥ��ֵ ��һ����Ӧֵ ��زο�����
    pop=popObj(pop,params);
    [pop, d, rho] = AssociateToReferencePoint(pop, params);
    fpopcm=preObj1(Samp,YS,popcm,nObj);
    for i=1:size(popc,1)
        popc(i).Cost=fpopcm(i,:)';
    end
    for i=s0+1:s0+size(popm,1)
        popm(i-s0).Cost=fpopcm(i,:)';
    end
    popc=popObj(popc,params); popm=popObj(popm,params);
    [popc, d, rho] = AssociateToReferencePoint(popc, params);
    [popm, d, rho] = AssociateToReferencePoint(popm, params);
  
    %%
%     add_uncertain;
    F1=select_ALLNO(Samp,YS);
    params.zmin = [];
    params.zmax = [];
    params.smin = [];
    [F1, params] = NormalizePopulation(F1, params);
    [F1, d, rho] = AssociateToReferencePoint(F1, params);
    
    %% ����Ԥ��ķ�֧���Ƿ�Ϊ��ķ�֧���
    nt=size(pop_test,1);
    F1_C=[F1.Cost];Nr=0;
    for i=1:nt
        if ismember(pop_test(i).Cost', F1_C','rows')
            Nr=Nr+1;
        end
    end
    if Nr/nt>=0.5
        Run_pop7=0;
    else
        Run_pop7=1;
    end
    
    
    % Show Iteration Information
    disp(['Iteration ' num2str(it) ': Number of F1 Members = ' num2str(numel(F1))]);
    it=it+1;

    Fcost1=[F1.Cost]';
    NFE
end

F1=select_ALLNO(Samp(1:maxNFE,:),YS(1:maxNFE,:));
for i=1:size(F1,1)
    PS(i).Position=F1(i).Position;
    PS(i).Cost=F1(i).Cost;
end
%% Results
t1=cputime-t0;
ys2=[F1.Cost];

