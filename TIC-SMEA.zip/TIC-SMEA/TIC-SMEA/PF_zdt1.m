function P = PF_zdt1(obj,N)
P(:,1) = (0:1/(N-1):1)';
P(:,2) = 1 - P(:,1).^0.5;
end