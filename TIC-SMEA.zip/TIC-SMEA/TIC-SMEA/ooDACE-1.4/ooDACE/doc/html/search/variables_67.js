var searchData=
[
  ['gamma',['gamma',['../class_basic_gaussian_process.html#a16edb7a9c03533f8bb4015a05ccd1bcb',1,'BasicGaussianProcess']]]
];
