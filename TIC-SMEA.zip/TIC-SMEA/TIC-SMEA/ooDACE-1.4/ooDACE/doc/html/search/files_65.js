var searchData=
[
  ['extrinsiccorrelationmatrix_2em',['extrinsicCorrelationMatrix.m',['../@_basic_gaussian_process_2extrinsic_correlation_matrix_8m.html',1,'']]],
  ['extrinsiccorrelationmatrix_2em',['extrinsicCorrelationMatrix.m',['../@_co_kriging_2extrinsic_correlation_matrix_8m.html',1,'']]]
];
