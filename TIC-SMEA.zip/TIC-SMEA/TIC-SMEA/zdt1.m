%
% Copyright (c) 2015, Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "license.txt" for license terms.
%
% Project Code: YPEA121
% Project Title: Multi-Objective Particle Swarm Optimization (MOPSO)
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: S. Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com
%

function  PopObj=zdt1(PopDec)

    PopObj(:,1) = PopDec(:,1);
            g = 1 + 9*sum(PopDec(:,2:end),2);
            h = 1 - (PopObj(:,1)./g).^0.5;
            PopObj(:,2) = g.*h; PopObj =PopObj';
end