function IM=EMI_Matrix(yBest,yhat,predvar)
[k,m]=size(yBest);

for i=1:k
    for j=1:m
        u  = (yBest(i,j) -  yhat(j))./sqrt(predvar(j));    
        IM(i,j)= (yBest(i,j)- yhat(j) ).*normcdf(u, 0, 1) +sqrt(predvar(j)).*normpdf(u, 0, 1);
    end
end